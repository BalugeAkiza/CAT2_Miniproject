/**
*<h2>School Registration</h2>
*<p>This is the interface of the mini-prject whihc will be loaded to the server and the client can retrieve </p>
*<p>It is an interface that will be loaded to the server so that the client can retrieve it </p>
<p>An interface is basically a classe whose do not have the implementation as shown in the code here</P>
*@author Innocent Baluge, Divne Lwaboshi and Nina Rosine
*@version 1.0
 */
import java.rmi.Remote; 
import java.rmi.RemoteException;  

public interface Interface extends Remote { 
   void registration() throws RemoteException; 
}