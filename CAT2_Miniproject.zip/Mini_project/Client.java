
/**
*<h2>School Registration</h2>
*<p>This is the Client side </p>
*<p>This Client side will display the actual window that the user will invoke by calling the client</p>
*@author Innocent Baluge, Divne Lwaboshi and Nina Rosine
*@version 1.0
 */
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
/**
*@exception Client this class will catch an error if t occurs while invoking the remote methods
 */

public class Client {
    private Client(){}
    public static void main(String[]args){
        try{
            Registry registry = LocateRegistry.getRegistry(null);
            Interface stub = (Interface) registry.lookup("Hello");
            stub.registration();
             System.out.println("Remote method invoked"); 
        }
         catch (Exception e) {
         System.err.println("Client exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
    }
}